<?php

/**
 * Fired during plugin activation
 *
 * @link       https://cedcommerce.com/
 * @since      1.0.0
 *
 * @package    Ced_product_filter
 * @subpackage Ced_product_filter/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Ced_product_filter
 * @subpackage Ced_product_filter/includes
 * @author     Cedcommerce <plugins@cedcommerce.com>
 */
class Ced_product_filter_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}


	/**
	 * ced_product_page
	 * Description : create a page during activatoin of pluign for show the product content
	 * Date : 8-1-2020
	 * @since 1.0.0	
	 * @return void
	 */
	public static function ced_shop_product_by_model_page() {
		global $wpdb;
		$get_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * from ".$wpdb->prefix."posts WHERE post_name = %s",'ced_shop_product_by_model_page'
			)
		);
		if(!empty($get_data)) {
		} else {
			$post_arr_data =  array(
				"post_title" => "Ced Shop By Model",
				"post_name" => "ced_shop_product_by_model_page",
				"post_status" => "publish",
				"post_type" => "page",
				"post_author" => 1,
				"post_content" => "Ced Shop By Model"
			);
			wp_insert_post($post_arr_data);
		}
	}


	/**
	 * ced_product_page
	 * Description : create a page during activatoin of pluign for show the product content
	 * Date : 8-1-2020
	 * @since 1.0.0	
	 * @return void
	 */
	public static function ced_categorised_product() {
		global $wpdb;
		$get_data = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * from ".$wpdb->prefix."posts WHERE post_name = %s",'ced_categorised_product'
			)
		);
		if(!empty($get_data)) {
		} else {
			$post_arr_data =  array(
				"post_title" => "Ced Categoridsed Product",
				"post_name" => "ced_categorised_product",
				"post_status" => "publish",
				"post_type" => "page",
				"post_author" => 1,
				"post_content" => "Ced Categoridsed Product"
			);
			wp_insert_post($post_arr_data);
		}
	}

}
