<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://cedcommerce.com/
 * @since      1.0.0
 *
 * @package    Ced_product_filter
 * @subpackage Ced_product_filter/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Ced_product_filter
 * @subpackage Ced_product_filter/includes
 * @author     Cedcommerce <plugins@cedcommerce.com>
 */
class Ced_product_filter_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
