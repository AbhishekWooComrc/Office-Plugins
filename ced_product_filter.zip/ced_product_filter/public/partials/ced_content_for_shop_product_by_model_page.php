
<?php 
get_header();
$printer_model = $_GET['printer_model'];
if($printer_model!=='') {
    // The query
    $products = new WP_Query( array(
        'post_type'      => array('product'),
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'meta_query'     => array( array(
            'key' => '_visibility',
            'value' => array('catalog', 'visible'),
            'compare' => 'IN',
        ) ),
        'tax_query'      => array( array(
            'taxonomy'        => 'pa_model',
            'field'           => 'slug',
            'terms'           =>  array($printer_model),
            'operator'        => 'IN',
        ) )
    ) );
    
    // The Loop
    if ( $products->have_posts() ): while ( $products->have_posts() ):
        $products->the_post();
        $product_ids[] = $products->post->ID;
    endwhile;
        wp_reset_postdata();
    endif;
    
    // TEST: Output the Products IDs
    ?>
    <div class="container">

        <div class="row ced_filtered_product_parent_wrapper">

            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 ced_product_filter_shortcode_content ced-product-filter">
                <?php echo do_shortcode("[ced_product_fiter_short_code]");?>
            </div>
           
            <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 ced_tabular_form_filtered_product">
            <div class='ced_cart_notice'>
                <a href="<?php echo home_url().'/cart/'?>" target="_blank"><div id='cart_added' class="ced_cart_info"></div></a>
            </div>
                <div class='ced_show_modeled_product_wrapper'>               
                    <table class="ced_show_modeled_product">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th> Action </th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    foreach($product_ids as $key => $productId) {
                        $product = wc_get_product( $productId );
                        $quantity = $product->get_stock_quantity();
                        $min = 0; 
                        if($quantity > 0) {
                            $min = 1;
                        }

                        ?>
                        <tr>
                            <td> <?php echo $product->get_image();?></td>
                            <td> <a href="<?php echo get_permalink($productId);?>"><?php echo $product->get_title();?></a></td>
                            <td> <?php echo $product->get_price_html();?></td>
                            <td>
                            
                                <input type="number" name="qty" id="quantity<?php echo $productId;?>" value="<?php echo $min;?>" class="qty" step="1" min="<?php echo $min;?>" max="<?php echo $quantity;?>" value="1" title="Qty" size="4" placeholder="" inputmode="numeric">

                
                        </td>
                            <td>
                            <?php 
                                
                                $price =  $product->get_price();
                                if( $quantity > 0 && $price > 0 ) {
                                    ?>
                                        <button class="cde_add_to_cart btn btn-danger" id="ced_modeled_added_cart" data-id="<?php echo $productId?>" data-title="<?php  echo $product->get_title(); ?>">Add to Cart</button>
                                        <div id="loader<?php echo $productId;?>" style="display: none;" class="ced_loader">
                                            <img src="https://staging-tonersusa.kinsta.cloud/wp-content/uploads/2021/02/Display-Loading.gif" alt="image">
                                        </div>
                                                                            <?php
                                } else {
                                    ?>
                                    <button class="cde_add_to_cart btn btn-danger" id="ced_modeled_out_iof_stock" disabled >Out of Stock</button></td>
                                    <?php
                                }
                            ?>
                        
                        </tr>
                        <?php
                    }
                    echo '</tbody>';
                    echo '</table>';
                    echo '</div>';
                }
                ?>
            </div>    
        </div>
    </div>
   <?php 
     get_footer();
   ?>