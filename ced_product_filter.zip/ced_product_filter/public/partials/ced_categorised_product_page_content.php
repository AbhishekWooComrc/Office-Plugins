<h1>Hello this is the content</h1>
<?php
get_header();
$brand_name = 'hp';
  $products = $wpdb->get_results($wpdb->prepare("SELECT product_id, name, instock, stocks, regular_price, sale_price, on_order
    FROM ".$wpdb->prefix."rd_woocommerce
    WHERE brand = %s
    ORDER BY name ASC
  ",$brand_name));

  foreach($products AS $product) {
    $description = $product->name;
    $instock = $product->instock;
    // $stocks = $product->stocks;
    /*This is added to overcome the stock conflict*/
    $stocks = get_post_meta($product->product_id,'_stock',true);
    if($stocks <= 0)
    {
      $stocks = 0;
    }
    $on_order = $product->on_order;
    $price = $product->regular_price;
    $product_id = $product->product_id;

    //show only items in stock
    if(!empty($stocks) && $price !== '0.00') {

      if(isset($_COOKIE['rd_pap_active_offer'])){
        $active_offer = $_COOKIE['rd_pap_active_offer'];
      } else {
        $active_offer = '';
      }

      if(empty($active_offer)) {
        $checkbox_disabled = 'disabled';
        $indicator = '<div class="rd_pap_checkbox_indicator" style="position: absolute; left: 0; right: 0; top:0; bottom:0;"></div>';
      } else {
        $checkbox_disabled = '';
        $indicator = '';
      }

      if(is_user_logged_in()) {
        $checkbox = '<input type="checkbox" class="rd_pap_checkbox" name="rd_pap_checkbox_[]" value="'.$product_id.'" '.$checkbox_disabled.' />';
      } else {
        $checkbox = '';
      }


      ?>
      <div class="rd_pap_line">
        <div class="rd_pap_col rd_pap_col_checkbox">
          <?php echo $checkbox; ?>
          <?php echo $indicator; ?>
        </div>
        <div class="rd_pap_col rd_pap_col_name"><?php echo $description; ?></div>
        <div class="rd_pap_col"><?php echo (int)$stocks; ?></div>
        <div class="rd_pap_col"><?php echo $on_order; ?></div>
        <div class="rd_pap_col">$ <?php echo $price; ?></div>
      </div><!--rd_pap_line-->
      <?php
      $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'single-post-thumbnail' );
      echo $image_url[0];
    }
  }//end foreach
get_footer();
