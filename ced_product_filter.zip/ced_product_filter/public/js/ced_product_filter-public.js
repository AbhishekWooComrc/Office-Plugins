(function( $ ) {
	'use strict';

	/**
	 * All of the code for your public-facing JavaScript source
	 * should reside in this file.
	 *
	 * Note: It has been assumed you will write jQuery code here, so the
	 * $ function reference has been prepared for usage within the scope
	 * of this function.
	 *
	 * This enables you to define handlers, for when the DOM is ready:
	 *
	 * $(function() {
	 *
	 * });
	 *
	 * When the window is loaded:
	 *
	 * $( window ).load(function() {
	 *
	 * });
	 *
	 * ...and/or other possibilities.
	 *
	 * Ideally, it is not considered best practise to attach more than a
	 * single DOM-ready or window-load handler for a particular page.
	 * Although scripts in the WordPress core, Plugins and Themes may be
	 * practising this, we should strive to set a better example in our own work.
	 */
	
	 $(document).ready(function(){
		var currentRequest = null; 
		$.ajax({
			url : frontend_ajax_object.ajaxurl,
			type : "POST",
  			data: {action:'ced_fetch_categories', nonce:frontend_ajax_object.nonce},
			success: function( response ) {
				$("#manufacturer_shop_by_brand").append(response);
				$("#manufacturer_shop_by_product").append(response);
			},
		})

		$('.by_shop').click(function(){
			// alert('hello');
			$('#ced_shop_by_brand').show();
			$('#ced_shop_by_product').hide();
			// $('#ced_shop_by_product').css('opacity: 0');
			// $('#ced_shop_by_brand').css('opacity: 1');
		})
		$('.by_product').click(function(){
			// alert('hello');
			$('#ced_shop_by_brand').hide();
			$('#ced_shop_by_product').show();
			$('#ced_shop_by_product').css('opacity', '1');
			// $('#ced_shop_by_brand').css('opacity: 0');
		})
		
		$("#manufacturer_shop_by_brand").on("change",function(){
			var selected_manufacturer = $("#manufacturer_shop_by_brand").val();
			

			$.ajax({
				url : frontend_ajax_object.ajaxurl,
				type : "POST",
				data: {action:'ced_fetch_attribute_printer_model',selected_category:selected_manufacturer,nonce:frontend_ajax_object.nonce},
				beforeSend: function () {
					$("#loader").show();
				  },
				success: function( response ) {
					$("#loader").hide();
					var parsed_response = jQuery.parseJSON(response);
					if(parsed_response!==''){
						$('#printer_model_shop_by_brand').html('');
						$("#printer_model_shop_by_brand").append(parsed_response.printer_model);

						$("#printer_model_shop_by_brand").on("change",function(){
							var pinter_model_val = $(this).val();
							if(pinter_model_val !=='') {

								var link = parsed_response.permalink;
								$("#find_shop_by_brand").attr('href',link+'?printer_model='+pinter_model_val);
								$("#find_shop_by_brand").attr('target','_blank');	

							}
						})
						
					}else {
						
					} 
				},
			})
		});



		
		$("#manufacturer_shop_by_product").on("change",function(){
			var selected_manufacturer = $("#manufacturer_shop_by_product").val();
			$("#search_title_shop_by_product").val('');
			let search_title ;
	
				$("#search_title_shop_by_product").on("keyup", function(e) {
				search_title = $(this).val();
			
				if(search_title !=='') {
				
					currentRequest = $.ajax({
						url : frontend_ajax_object.ajaxurl,
						type : "POST",
						data: {action:'ced_fetch_product_title',selected_category:selected_manufacturer,search_title:search_title,nonce:frontend_ajax_object.nonce},
						beforeSend : function()    { 
							$("#ced_model_loader").show();          
							if(currentRequest != null) {
								currentRequest.abort();
							}
						},
						success: function( response ) {
							$("#ced_model_loader").hide();
							if(response!==''){
								$('#product_title').html('');
								$('#product_title').append(response);
								$(document).on("click", ".ced_link_prod_title", function () {
									$("#search_title_shop_by_product").val($(this).text());
									$("#product_title").html("");
									$('#find_shop_by_product').focus();
									var prod_premalink = $(this).data("pid");
									$("#find_shop_by_product").attr('href',prod_premalink);
									$("#find_shop_by_product").attr('target','_blank');	
								});
								
							} else {

							}	
						},
					})
				}	
			});				
		});
	
		
		
		$(document).on('click', '#ced_modeled_added_cart', function(){

			var prod_id = $(this).data("id");
			var quantity = $('#quantity'+prod_id).val();
			var prod_title = $(this).data("title");
			$.ajax({
				url : frontend_ajax_object.ajaxurl,
				type : "POST",
				data: {action:'ced_add_to_cart_redirection',prod_id:prod_id,qty:quantity,nonce:frontend_ajax_object.nonce},
				beforeSend: function () {
					$("#loader"+prod_id).show();
				},
				success: function( response ) {
					$("#loader"+prod_id).hide();
					$('#cart_added').html(prod_title + 'Has added to your cart');
					$('#cart_added').fadeIn(500);
					$('#cart_added').fadeOut(7000);
					
				},
			})
		})
	})

})( jQuery );
