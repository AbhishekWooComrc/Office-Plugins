<?php

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://cedcommerce.com/
 * @since      1.0.0
 *
 * @package    Ced_product_filter
 * @subpackage Ced_product_filter/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Ced_product_filter
 * @subpackage Ced_product_filter/public
 * @author     Cedcommerce <plugins@cedcommerce.com>
 */
class Ced_product_filter_Public {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Register the stylesheets for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Ced_product_filter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Ced_product_filter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */

		wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/ced_product_filter-public.css', array(), $this->version, 'all' );
		}

	/**
	 * Register the JavaScript for the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Ced_product_filter_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Ced_product_filter_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		wp_enqueue_script( 'jquery' );
		wp_enqueue_script( 'ced_js', plugin_dir_url( __FILE__ ) . 'js/ced_product_filter-public.js', array( 'jquery' ), time(), false );
		wp_localize_script( 'ced_js', 'frontend_ajax_object',
        array( 
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce('verify-ajax-call'),
		));	
	}

	 

	/**
	 * Ced_product_filter_content_shortcode
	 * Description : Used for show the whole content of product filter
	 * 
	 * @since 1.0.0
	 * 
	 * @return void
	 */
	public function ced_product_filter_content_shortcode() { 
		
			$message = '<!DOCTYPE html>
						<html lang="en">
						<head>
						<meta charset="utf-8">
						<meta name="viewport" content="width=device-width, initial-scale=1">
						<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
												
						<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
						</head>
						<body>
						
					<div class="container">
						<ul class="nav nav-tabs">
							<li class="by_shop active"><a data-toggle="tab" href="">SHOP BY BRAND</a></li>
							<li class="by_product"><a data-toggle="tab" href="">SHOP BY PRODUCT</a></li>
						</ul>
						
						<div class="tab-content">
							<div id="ced_shop_by_brand" class="tab-pane fade in active">
								<div class="ced_filter_title">SHOP BY BRAND</div>

								<div class="ced_manufacturer_name_wrapper">
									<div class="ced_manufacturer_label"><label for="manufacturer_shop_by_brand" class="ced_manufacturer_name"> Manufacturer :</label></div>
									<div class="ced_manufacturer_select_box"><select id="manufacturer_shop_by_brand" class="ced_manufacturer_options" name="manufacturer_shop_by_brand">
										<option disabled selected>Select Manufacturer </option>
									</select> </div>
								</div>
								<div class="ced_printer_model_wrapper">
									<div class= "ced_printer_model_label"><label for="manufacturer_shop_by_brand" class="ced_printer_model_name"> Printer Model : </label></div>
									<div class= "ced_printer_model_select_box"><select id="printer_model_shop_by_brand" class="ced_printer_model_options" name="printer_model_shop_by_brand">
										<option disabled selected>Select Printer Model </option>
									</select></div>
									<div id="loader" style="display: none;" class="ced_loader">
										<img src="https://staging-tonersusa.kinsta.cloud/wp-content/uploads/2021/02/Display-Loading.gif" alt="image">
									</div>
								</div>

								
								<div class="ced_product_filter_button"><a href="javascript:void(0)" target="" class="btn btn-danger" id="find_shop_by_brand">Find Products</a></div>
								
							</div>

							<div id="ced_shop_by_product" class="tab-pane fade">
								<div class="ced_filter_title">SHOP BY PRODUCT</div>

								<div class="ced_manufacturer_name_wrapper">
									<div class="ced_manufacturer_label"><label for="manufacturer_shop_by_product" class="ced_manufacturer_name"> Manufacturer :</label></div>
									<div class="ced_manufacturer_select_box"><select id="manufacturer_shop_by_product" class="ced_manufacturer_options" name="manufacturer_shop_by_product">
										<option disabled selected>Select Manufacturer</option>
									</select></div>
								</div>
								<div class="ced_printer_model_wrapper">
									<div class= "ced_printer_model_label"><label for="search_title_shop_by_product" class="ced_printer_model_name"> Search Items : </label></div>
									<input type="text" id="search_title_shop_by_product" class="ced_printer_model_options" name="search_manufacturer_shop_by_product">
									<div id="ced_model_loader" style="display: none;" class="ced_loader">
										<img src="https://staging-tonersusa.kinsta.cloud/wp-content/uploads/2021/02/Display-Loading.gif" alt="image">
									</div>
									<div class="ced_list_filtered_product"><div id= "product_title" class="ced_list_all_product"></div></div>
									
								</div>
								<div class="ced_product_filter_button"><a href="javascript:void(0)" target="" class="btn btn-danger" id="find_shop_by_product">Find Products</a></div>
							</div>
						</div>
					</div>
					</body>
					</html>
						'; 
			return $message;
	} 
	
	/**
	 * Ced_fetch_manufacturer_categories
	 * Description : Fetch the categories from DB, and show the content in dropdown list 
	 * 
	 * @since 1.0.0
	 * 
	 * @return void
	 */
	public function ced_fetch_manufacturer_categories() {
		if (check_ajax_referer('verify-ajax-call', 'nonce')) {
			$orderby = 'name';
			$order = 'asc';
			$hide_empty = false ;
			$cat_args = array(
				'orderby'    => $orderby,
				'order'      => $order,
				'hide_empty' => $hide_empty,
			);
			
			$product_categories = get_terms( 'product_cat', $cat_args );
			if( !empty($product_categories)) {
				$str = "";

				foreach ($product_categories as $key => $category) {
		
				if($category->name != 'Danka'&& $category->name != 'FujiFilm'&& $category->name != 'Gestetner'&& $category->name != 'IBM'&& $category->name != 'KIP'&& $category->name != 'Kodak'&& $category->name != 'Lanier'&& $category->name != 'Mita'&& $category->name != 'Muratec'&& $category->name != 'Nec'&& $category->name != 'Neopost'&& $category->name != 'Printronix'&& $category->name != 'Savin'&& $category->name != 'Troy'&& $category->name != 'Tally'&& $category->name != 'Uncategorized'&& $category->name != 'Custom') {
					$str .= "<option value='" . $category->term_id . "'>" . $category->name . "</option>";
				}	
					
				}
				echo $str;
			} else {
				echo '0';
			}
		}
		wp_die();


	}

	/**
	 * Ced_fetch_printermodel_attributes
	 * Description : Fetch the product attributes (PRINTER MODEL) from DB, and show the content in dropdown list 
	 * 
	 * @since 1.0.0
	 * 
	 * @return void
	 */
	public function ced_fetch_printermodel_attributes() {
		if (check_ajax_referer('verify-ajax-call', 'nonce')) {
			$selected_manufacturer =  isset($_POST['selected_category'])? sanitize_text_field($_POST['selected_category']) : '';
			global $woocommerce;
			global $product;

			$query = [];
			$query = get_posts(
				array(
					'numberposts'=>-1,
					'post_type'=>'product',
					'tax_query' => array(
						array(
							array(
								'taxonomy' => 'product_cat',
								'field'    => 'term_id',
								'terms'     => $selected_manufacturer,
								'operator'  => 'IN'
							),
						),	
					),
					'fields'=>'ids'
				)
				);
			if(!empty($query)) {
				$str = "";
				$str .= "<option disabled selected > Select Printer Model </option>";
				$attribute_slug = array();
				$unique_attribute_slug = array();
				foreach ( $query as $id ) {
					$values = wc_get_product_terms( $id, 'pa_model', array( 'fields' => 'all' ) );
					foreach($values as $val){
						$attribute_slug[] = ($val->slug);
						$unique_attribute_slug = array_unique($attribute_slug);
							
					}

					$permalink = home_url().'/ced_shop_product_by_model_page';
				}
				foreach($unique_attribute_slug as $key => $slug_val) {

					$str .= "<option value='" . $slug_val . "'>" . $slug_val . "</option>";
				}
				$ced_product_content = array("printer_model"=>$str, "permalink"=>$permalink);
				$ced_product_content = json_encode($ced_product_content);
				echo ($ced_product_content);
			}
		} 	
	   wp_die();
	}
	



	/**
	 * Ced_fetch_product_title
	 * Description : this function is used for fetch the product_title with  ajax call and render the founded data into form of html
	 * 
	 * @since 1.0.0
	 * @return void
	 */
	public function ced_fetch_product_title() {

		if (check_ajax_referer('verify-ajax-call', 'nonce')) {
			$selected_manufacturer =  isset($_POST['selected_category'])? sanitize_text_field($_POST['selected_category']) : '';
			$search_title = isset($_POST['search_title'])? sanitize_text_field($_POST['search_title']) : '';
			global $woocommerce;
			global $product;

		$query = [];
		$query = get_posts(
			array(
				'numberposts'=>-1,
				'post_type'=>'product',
				'tax_query' => array(
					array(
						array(
							'taxonomy' => 'product_cat',
							'field'    => 'term_id',
							'terms'     => $selected_manufacturer,
							'operator'  => 'IN'
						),
					),	
				),
				'fields'=>'ids'
			)
			);

			if(!empty($query)) {
				global $wpdb;
				$str = '';
				foreach ( $query as $id ) {
				
					$prod_title = $wpdb->get_var( "SELECT post_title FROM {$wpdb->prefix}posts WHERE  `post_title` LIKE '%$search_title%' AND `ID` = $id " );
					if(strlen($prod_title) >= 1) {
						$str.="<a data-pid='".get_permalink( $id )."' class='ced_link_prod_title'><div>".$prod_title."</div></a>";
					}
				}
				
				if($str){
					echo $str;
				} else {
					echo "Product Not Found";
				}

			}
		}	
	   wp_die();
	}



	
	/**
	 * Ced_content_for_shop_product_by_model_page
	 * Description : This function is used for show the whole product of specific attribute model in the form of html
	 * 
	 * @since 1.0.0 
	 * @param  mixed $template
	 * @return void
	 */
	public function ced_content_for_shop_product_by_model_page($template)
	{
		// get_query_var('pagename') is used for select the page_name
		$page_name = get_query_var('pagename');
		if($page_name == 'ced_shop_product_by_model_page'){
			$template = plugin_dir_path(__FILE__). 'partials/ced_content_for_shop_product_by_model_page.php';
		} 
		return $template;	
	}

	


	/**
	 * Ced_add_to_cart_redirection
	 * Discription : function is used for perform the proporties of add-to-cart
	 * 
	 * @since 1.0.0
	 * @return void
	 */
	public function ced_add_to_cart_redirection() {
		if (check_ajax_referer('verify-ajax-call', 'nonce')) {
			// print_r($_POST);
			global $woocommere;
			$found = false;
			$selected_prod_id =  isset($_POST['prod_id'])? sanitize_text_field($_POST['prod_id']) : '';
			$sleceted_prod_quantity = isset($_POST['qty'])? sanitize_text_field($_POST['qty']) : '';
			//check if product already in cart
			$found = false;
			//check if product already in cart
			if ( sizeof( WC()->cart->get_cart() ) > 0 ) {
				foreach ( WC()->cart->get_cart() as $cart_item_key => $values ) {
					$_product = $values['data'];
					if ( $_product->get_id() == $selected_prod_id )
						$quantity = $values['quantity'];
						$sleceted_prod_quantity = $sleceted_prod_quantity + $quantity;
						$found = true;
						WC()->cart->add_to_cart( $selected_prod_id , $sleceted_prod_quantity );

				}
				// if product not found, add it
				if ( ! $found )
					WC()->cart->add_to_cart( $selected_prod_id , $sleceted_prod_quantity );
			} else {
				// if no products in cart, add it
				WC()->cart->add_to_cart( $selected_prod_id , $sleceted_prod_quantity );
			}
		}
			
		wp_die();

	}


		/**
	 * Ced_categorised_product_page_content
	 * Description : This function is used for show the whole product of specific attribute model in the form of html
	 * 
	 * @since 1.0.0 
	 * @param  mixed $template
	 * @return void
	 */
	public function ced_categorised_product_page_content($template)
	{
		// get_query_var('pagename') is used for select the page_name
		$page_name = get_query_var('pagename');
		if($page_name == 'ced_categorised_product'){
			$template = plugin_dir_path(__FILE__). 'partials/ced_categorised_product_page_content.php';
		} 
		return $template;	
	}


}
